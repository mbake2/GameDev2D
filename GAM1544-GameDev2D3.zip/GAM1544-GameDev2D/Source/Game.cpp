﻿#include "Game.h"


namespace GameDev2D
{
	Game::Game()
	{

	}

	Game::~Game()
	{

	}

	void Game::OnUpdate(float delta)
	{

	}

	void Game::OnRender(BatchRenderer& batchRenderer)
	{
		batchRenderer.BeginScene();

		//Render your Sprites and SpriteFonts here

		batchRenderer.EndScene();
	}

	void Game::OnKeyEvent(KeyCode keyCode, KeyState keyState)
	{
		
	}

	void Game::OnMouseButtonEvent(MouseButton button, MouseButtonState state, float mouseX, float mouseY)
	{
		
	}

	void Game::OnMouseMovedEvent(float mouseX, float mouseY)
	{

	}
}